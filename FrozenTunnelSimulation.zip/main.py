def count_melted_ice(tunnel: str) -> int:
    tunnel = list(tunnel)  # عشان نقدر نعدل بسهولة
    total_melted = 0
    changed = True

    while changed:
        changed = False
        melt_indices = []
        n = len(tunnel)

        # نلاقي كل "___" ونحدد أي I بعدها
        for i in range(n - 3):
            if tunnel[i] == '_' and tunnel[i+1] == '_' and tunnel[i+2] == '_':
                if i+3 < n and tunnel[i+3] == 'I':
                    melt_indices.append(i+3)

        # لو فيه أي يذوب، نحدث السلسلة
        if melt_indices:
            changed = True
            for idx in melt_indices:
                tunnel[idx] = '_'
            total_melted += len(melt_indices)

    return total_melted


# أمثلة للتجربة
if __name__ == "__main__":
    print(count_melted_ice("I___I_I"))  # Output: 2
    print(count_melted_ice("I__I__I"))  # Output: 0
